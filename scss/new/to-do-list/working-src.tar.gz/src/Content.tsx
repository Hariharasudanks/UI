import * as React from 'react';
import './style.css';

import Listcontent from './Listcontent';
import Rightsidenav from './Rightsidenav';
import Sidenav from './Sidenav';

class Content extends React.Component<{},{ currentList: number, currentTask: number }>{
  constructor(props: {}) {
    super(props);
    this.state = {
      currentList: 0,
      currentTask: 0,
    };
  }
  public setCurrentList = (index:number)=> {
    this.setState({
      currentList: index
    });
    // alert("////Inside Content index is: "+index);
  }

  public render() {
    return (
      <div className="contents">
        <Sidenav setCurrentList = {this.setCurrentList}/>
        <Listcontent activeList={this.state.currentList}/>
        <Rightsidenav />
      </div>
    );
  }
}

export default Content;
