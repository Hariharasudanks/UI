import Lists from './list';

const Store:Lists[] = []


export default Store;