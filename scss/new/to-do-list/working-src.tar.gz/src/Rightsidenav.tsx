import * as React from 'react';
import './style.css';



class Rightsidenav  extends React.Component {
  public render() {
    return (
      <div className="side-content">
  <div className="right-top-content-one">
    <div className="content">
    <button className="fa fa-circle-thin button class"/>
  <span className="content-span">Lorem ipsum is the dummy text of the printing and typesetting industry</span>
  <button className="fa fa-star-o right-float" aria-hidden="true"/>

    </div>
  </div>
  <br/>
  <div className="right-top-content-two">
    <div className="content-2">
    <button className="fa fa-sun-o button-class "/>
    <span>Add to my day</span>
  </div>
</div>
<br/>
<div className="right-top-content-three">
  <div className ="content-3">
    <div className="inner-div-1">
  <button className="fa fa-clock-o button-class "/>
</div>
    <div className="inner-div-2">
  <span className="dateTwo">Remind Me</span>
  <input className="datetwoTwo" type ="date"/>
</div>
<br/>
<div className="inner-div-1">
<button className="fa fa-calendar button-class "/>
</div>
<div className="inner-div-2">
<span className="dateOne">Add Due Date</span>
<input className="dateoneOne" type ="date"/>
</div>
<br/>
<div className="inner-div-1">
<button className="fa fa-repeat button-class "/>
</div>
<div className="inner-div-2">
<span>Repeat</span>
</div>

</div>
</div>
<br/>
<div className="right-top-content-four">
  <div className="content-4">
  <textarea className="note" rows={4} cols={50} placeholder="Add a note..."/>
 </div>
</div>
<div className="bottom-right">
  <div className="left-bottom-content-one">
    <div className="content">
    <button className="fa fa-chevron-right button class"/>
  <span>Completed Today</span>
  <button className="fa fa-trash-o right-float delete" aria-hidden="true"/>
    </div>
  </div>
</div>

</div>

    );
  }
}

export default Rightsidenav;

