import * as React from 'react';
import './style.css';

import Store from './Store';

class Listcontent extends React.Component<{activeList:number}> {



public findListById(listId : number) {
  let list ;
 // let id = parseInt(listId,10);
  // console.log("Length"+Store.length);
  for(const listItem of Store) {
 // console.log("aa " +listItem.getId());
 // console.log("param ID: "+listId);
  
  if(listItem.getId() === listId ) {
  list = listItem;
  alert("Name is: "+list.getName());
  }
  
  
  }
  return list;
  }


  public render() {
    const list = this.findListById(this.props.activeList)
    return (
     
      <div className="list-content">
  <div className="heading">
 {(list == null ? "MyList":list.getName())}
</div>

<div className="sort">
<button className="fa fa-exchange fa-rotate-90 button-class"/>
</div>
<div className="list-inner-content">

  <ul className="ul"/>
  <div className="add-task">
  <button className="fa fa-plus click-plus button-class"/>
  <input className="input-text" placeholder="Add a task"/>
  <button className="add-class">ADD</button>
</div>
</div>
</div>

    );
  }
}

export default Listcontent;



